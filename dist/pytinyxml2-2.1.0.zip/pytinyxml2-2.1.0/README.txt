pytinyxml2
------------------------

  My second library to wrap the tinyxml2 library

Installation
------------------------

  Just like other ones, just type:

    pip install pytinyxml2

  And that's all.